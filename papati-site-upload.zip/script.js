const menuItems = [
  { name: "قهوة بندق", nameEn: "Hazelnut Coffee", category: "hot", icon: "☕" },
  { name: "قهوة تركي دبل", nameEn: "Double Turkish Coffee", category: "hot", icon: "☕" },
  { name: "إسبريسو دبل", nameEn: "Double Espresso", category: "hot", icon: "☕" },
  { name: "إسبريسو سنجل", nameEn: "Single Espresso", category: "hot", icon: "☕" },
  { name: "قهوة تركي سنجل", nameEn: "Single Turkish Coffee", category: "hot", icon: "☕" },
  { name: "شاي وفواكه", nameEn: "Fruit Tea", category: "hot", icon: "🍵" },
  { name: "شاي نعناع", nameEn: "Mint Tea", category: "hot", icon: "🍵" },
  { name: "كابتشينو دبل إسبريسو", nameEn: "Double Espresso Cappuccino", category: "hot", icon: "☕" },
  { name: "شاي", nameEn: "Tea", category: "hot", icon: "🍵" },
  { name: "لاتيه ساخن", nameEn: "Hot Latte", category: "hot", icon: "☕" },
  { name: "يانسون", nameEn: "Anise Tea", category: "hot", icon: "🍵" },
  { name: "كاكاو", nameEn: "Cocoa", category: "hot", icon: "☕" },
  { name: "قرفة", nameEn: "Cinnamon Tea", category: "hot", icon: "🍵" },
  { name: "زنجبيل", nameEn: "Ginger Tea", category: "hot", icon: "🍵" },
  { name: "بونجورنو", nameEn: "Buongiorno", category: "hot", icon: "☕" },
  { name: "كاكاو باللبن", nameEn: "Cocoa with Milk", category: "hot", icon: "☕" },
  { name: "شاي أخضر", nameEn: "Green Tea", category: "hot", icon: "🍵" },
  { name: "نعناع", nameEn: "Mint", category: "hot", icon: "🍵" },
  { name: "فلات وايت دبل", nameEn: "Double Flat White", category: "hot", icon: "☕" },
  { name: "كورتادو دبل", nameEn: "Double Cortado", category: "hot", icon: "☕" },
  { name: "ماكياتو دبل", nameEn: "Double Macchiato", category: "hot", icon: "☕" },
  { name: "شاي لبن", nameEn: "Milk Tea", category: "hot", icon: "🍵" },
  { name: "قهوة تركي زيادة", nameEn: "Extra Turkish Coffee", category: "hot", icon: "☕" },
  { name: "أمريكانو", nameEn: "Americano", category: "hot", icon: "☕" },
  { name: "كراميل ماكياتو", nameEn: "Caramel Macchiato", category: "hot", icon: "☕" },
  { name: "سبانيش لاتيه", nameEn: "Spanish Latte", category: "hot", icon: "☕" },
  { name: "موكا لاتيه", nameEn: "Mocha Latte", category: "hot", icon: "☕" },
  { name: "شاي فتلة", nameEn: "Tea Bag", category: "hot", icon: "🍵" },
  { name: "هوت شوكليت", nameEn: "Hot Chocolate", category: "hot", icon: "🍫" },
  { name: "آيس لاتيه", nameEn: "Iced Latte", category: "cold", description: "إسبريسو مع حليب بارد وثلج", descriptionEn: "Espresso with cold milk and ice", price: 80, icon: "🧋", badge: "اختيارنا", badgeEn: "Our pick" },
  { name: "آيس سبانيش", nameEn: "Iced Spanish Latte", category: "cold", description: "حلاوة الحليب المكثف مع قهوة باردة", descriptionEn: "Sweet condensed milk blended with chilled coffee", price: 90, icon: "🧊" },
  { name: "كولد برو", nameEn: "Cold Brew", category: "cold", description: "قهوة منقوعة ببطء لمدة 18 ساعة", descriptionEn: "Slow-steeped coffee, brewed for 18 hours", price: 95, icon: "🥤" },
  { name: "ليمون نعناع", nameEn: "Lemon Mint", category: "cold", description: "ليمون فريش ونعناع منعش", descriptionEn: "Fresh lemon and refreshing mint", price: 65, icon: "🍋" },
  { name: "عصير ليمون فريش", nameEn: "Fresh Lemon Juice", category: "cold", icon: "🍋" },
  { name: "عصير مانجو فريش", nameEn: "Fresh Mango Juice", category: "cold", icon: "🥭" },
  { name: "ايس موكا", nameEn: "Iced Mocha", category: "cold", icon: "☕" },
  { name: "ايس امريكانو", nameEn: "Iced Americano", category: "cold", icon: "☕" },
  { name: "ايس كراميل ميكاتو", nameEn: "Iced Caramel Macchiato", category: "cold", icon: "☕" },
  { name: "موكا فرابيه", nameEn: "Mocha Frappe", category: "cold", icon: "☕" },
  { name: "كراميل فرابيه", nameEn: "Caramel Frappe", category: "cold", icon: "☕" },
  { name: "فانيليا فرابيه", nameEn: "Vanilla Frappe", category: "cold", icon: "☕" },
  { name: "ميلك شيك فراولة", nameEn: "Strawberry Milkshake", category: "cold", icon: "🥤" },
  { name: "ميلك شيك كافي", nameEn: "Coffee Milkshake", category: "cold", icon: "☕" },
  { name: "ميلك شيك شوكلت", nameEn: "Chocolate Milkshake", category: "cold", icon: "🍫" },
  { name: "ميلك تشيك فانيليا", nameEn: "Vanilla Milkshake", category: "cold", icon: "🥤" },
  { name: "ميلك تشيك مانجو", nameEn: "Mango Milkshake", category: "cold", icon: "🥭" },
  { name: "سموزي مانجو", nameEn: "Mango Smoothie", category: "cold", icon: "🥭" },
  { name: "سموزي فراولة", nameEn: "Strawberry Smoothie", category: "cold", icon: "🍓" },
  { name: "سموزي بلو بيري", nameEn: "Blueberry Smoothie", category: "cold", icon: "🫐" },
  { name: "سموزي مكس بيري", nameEn: "Mixed Berry Smoothie", category: "cold", icon: "🫐" },
  { name: "سموزي ليمون نعناع", nameEn: "Lemon Mint Smoothie", category: "cold", icon: "🍋" },
  { name: "سموزي باشون فروت", nameEn: "Passion Fruit Smoothie", category: "cold", icon: "🥭" },
  { name: "سموزي كريز", nameEn: "Cherry Smoothie", category: "cold", icon: "🍒" },
  { name: "موهيتو صن شاين", nameEn: "Sun Shine Mojito", category: "cold", icon: "🍋" },
  { name: "موهيتو بلو هاوي", nameEn: "Blue Hawaii Mojito", category: "cold", icon: "🫐" },
  { name: "موهيتو همر هاد", nameEn: "Hammer Head Mojito", category: "cold", icon: "🍋" },
  { name: "موهيتو سكوتش مينت", nameEn: "Scottish Mint Mojito", category: "cold", icon: "🍃" },
  { name: "موهيتو ريدبول كراش", nameEn: "Red Bull Crash Mojito", category: "cold", icon: "⚡" },
  { name: "موهيتو باشون", nameEn: "Passion Mojito", category: "cold", icon: "🥭" },
  { name: "بيبسي", nameEn: "Pepsi", category: "cold", icon: "🥤" },
  { name: "تويست", nameEn: "Twist", category: "cold", icon: "🥤" },
  { name: "ستينج", nameEn: "Sting", category: "cold", icon: "⚡" },
  { name: "ريدبول", nameEn: "Red Bull", category: "cold", icon: "⚡" },
];

function resolveProductPhoto(item, index) {
  const name = `${item.name} ${item.nameEn}`.toLowerCase();
  const teaSet = ["tea-01.jpg", "tea-02.jpg", "tea-03.jpg", "tea-04.jpg"];

  if (item.icon === "🍵" || /شاي|tea|نعناع|mint|قرفة|زنجبيل|يانسون|أخضر|ginger|cinnamon|anise|fruit/i.test(name)) {
    return teaSet[index % teaSet.length];
  }

  if (item.category === "hot" && (item.icon === "🍫" || /كاكاو|chocolate|شوكليت|cocoa/i.test(name))) {
    return "hot-chocolate-01.jpg";
  }

  if (/عصير ليمون فريش|fresh lemon juice/i.test(name)) return "lemon-drink-01.jpg";

  if (item.category === "cold") {
    if (/لاتيه|latte|موكا|mocha|امريكانو|americano|ماكياتو|macchiato|كولد برو|cold brew|فرابيه|frappe/i.test(name)) {
      return /لاتيه|latte|ماكياتو|macchiato/i.test(name) ? "latte-01.jpg" : "iced-coffee-01.jpg";
    }
    return null;
  }

  if (/اسبريسو|espresso/i.test(name)) return "espresso-01.jpg";
  if (/لاتيه|latte|كابتشينو|cappuccino|فلات وايت|flat white|كورتادو|cortado|ماكياتو|macchiato/i.test(name)) {
    return "latte-01.jpg";
  }
  return ["coffee-cup-01.jpg", "coffee-cup-02.jpg", "coffee-cup-03.jpg", "cafe-coffee-01.jpg"][index % 4];
}


const translations = {
  ar: {
    pageTitle: "PAPATI | قهوتك على مزاجك",
    description: "منيو PAPATI — قهوة ومشروبات معمولة بحب.",
    welcomeKicker: "أهلاً بيك في PAPATI",
    welcomeTitle: ["قهوتك الحلوة", "مستنياك."],
    welcomeDescription: "اختار مشروبك المفضل، وخلي يومك أحلى مع PAPATI.",
    welcomeButton: "دخول للمنيو",
    welcomeCaption: "قهوة معمولة بحب، على مزاجك",
    openingHoursLabel: "ساعات العمل",
    openingHours: "يوميًا · ٨ صباحًا – ١٢ منتصف الليل",
    brandAria: "PAPATI - الصفحة الرئيسية",
    locationAria: "افتح موقع PAPATI على خرائط جوجل",
    tagline: "قهوة على مزاجك",
    menuEyebrow: "اختار اللي على مزاجك",
    menuTitle: "منيو",
    menuDescription: "حاجات حلوة تتعمل مخصوص عشانك.",
    searchPlaceholder: "بتدور على إيه؟",
    searchAria: "ابحث في المنيو",
    categoriesAria: "أقسام المنيو",
    categoryAll: "كل الحاجات",
    categoryHot: "☕ سخن",
    categoryCold: "🧊 ساقع",
    emptyState: "ملقيناش حاجة بالاسم ده… جرّب تدور على حاجة تانية.",
    menuFootnote: "* الأسعار غير متوفرة لكل المشروبات حاليًا. الأسعار المعروضة بالجنيه المصري.",
    footerMessage: "نورتنا، مستنيين زيارتك الجاية",
    copyright: "© 2026 PAPATI كافيه",
    switchLanguage: "Switch language to English",
    currency: "ج.م",
  },
  en: {
    pageTitle: "PAPATI | Coffee your way",
    description: "PAPATI menu — coffee and drinks, made with love.",
    welcomeKicker: "Welcome to PAPATI",
    welcomeTitle: ["Your coffee moment", "is waiting."],
    welcomeDescription: "Pick your favorite, and make today a little sweeter with PAPATI.",
    welcomeButton: "Enter the menu",
    welcomeCaption: "Made with love, just your way",
    openingHoursLabel: "Opening hours",
    openingHours: "Daily · 8:00 AM – 12:00 AM",
    brandAria: "PAPATI - Home",
    locationAria: "Open PAPATI location in Google Maps",
    tagline: "Coffee your way",
    menuEyebrow: "Find your new favorite",
    menuTitle: "Menu",
    menuDescription: "Good things, made just for you.",
    searchPlaceholder: "What are you craving?",
    searchAria: "Search the menu",
    categoriesAria: "Menu categories",
    categoryAll: "Everything",
    categoryHot: "☕ Hot",
    categoryCold: "🧊 Cold",
    emptyState: "Nothing found. Try searching for something else.",
    menuFootnote: "* Prices are listed for selected drinks only. All displayed prices are in EGP.",
    footerMessage: "Thanks for stopping by. See you again soon",
    copyright: "© 2026 PAPATI Café",
    switchLanguage: "تغيير اللغة إلى العربية",
    currency: "EGP",
  },
};

const menuGrid = document.querySelector("#menu-grid");
const searchInput = document.querySelector("#menu-search");
const emptyState = document.querySelector("#empty-state");
const categoryButtons = [...document.querySelectorAll(".category-button")];
const languageToggles = [...document.querySelectorAll(".language-toggle")];
const welcomeScreen = document.querySelector("#welcome-screen");
const siteContent = document.querySelector("#site-content");
const enterMenuButton = document.querySelector("#enter-menu");
let selectedCategory = "all";
let currentLanguage = "ar";
let animateMenuTransition = false;

function getIllustration(item) {
  const illustration = document.createElement("span");
  illustration.className = "image-fallback";
  illustration.setAttribute("aria-hidden", "true");
  illustration.textContent = item.icon;
  return illustration;
}

function normalizeSearchText(text) {
  return text
    .toLocaleLowerCase(currentLanguage)
    .normalize("NFD")
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآ]/g, "ا");
}

function renderMenu() {
  const query = normalizeSearchText(searchInput.value.trim());
  const visibleItems = menuItems.filter((item) => {
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    const searchableText = normalizeSearchText(`${item.name} ${item.nameEn} ${item.description || ""} ${item.descriptionEn || ""}`);
    return matchesCategory && searchableText.includes(query);
  });

  const cards = visibleItems.map((item, index) => {
    const name = currentLanguage === "ar" ? item.name : item.nameEn;
    const description = currentLanguage === "ar" ? item.description : item.descriptionEn;
    const badge = currentLanguage === "ar" ? item.badge : item.badgeEn;
    const card = document.createElement("article");
    card.className = "menu-card";
    if (animateMenuTransition) {
      card.classList.add("is-entering");
      card.style.setProperty("--item-index", Math.min(index, 8));
    }

    const artwork = document.createElement("span");
    artwork.className = `item-art ${item.category}`;
    artwork.setAttribute("aria-hidden", "true");
    const photo = resolveProductPhoto(item, menuItems.indexOf(item));
    if (photo) {
      const image = document.createElement("img");
      image.className = "item-photo";
      image.src = `assets/drinks/${photo}`;
      image.alt = "";
      image.loading = index < 6 ? "eager" : "lazy";
      image.addEventListener("error", () => artwork.replaceChildren(getIllustration(item)), { once: true });
      artwork.append(image);
    } else {
      artwork.append(getIllustration(item));
    }
    card.append(artwork);

    const details = document.createElement("div");
    details.className = "item-details";
    const heading = document.createElement("h3");
    heading.textContent = name;
    details.append(heading);
    if (description) {
      const descriptionElement = document.createElement("p");
      descriptionElement.textContent = description;
      details.append(descriptionElement);
    }
    if (item.price !== undefined) {
      const price = document.createElement("span");
      price.className = "item-price";
      price.append(document.createTextNode(item.price.toLocaleString(currentLanguage === "ar" ? "ar-EG" : "en")));
      const currency = document.createElement("small");
      currency.textContent = translations[currentLanguage].currency;
      price.append(currency);
      details.append(price);
    }
    card.append(details);

    if (badge) {
      const badgeElement = document.createElement("span");
      badgeElement.className = "item-badge";
      badgeElement.textContent = badge;
      card.append(badgeElement);
    }
    return card;
  });

  menuGrid.replaceChildren(...cards);
  animateMenuTransition = false;
  emptyState.hidden = visibleItems.length > 0;
}

function setLanguage(language) {
  currentLanguage = language;
  const copy = translations[language];
  document.documentElement.lang = language;
  document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  document.title = copy.pageTitle;
  document.querySelector('meta[name="description"]').content = copy.description;

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.dataset.i18n;
    if (key === "welcomeTitle") {
      const [firstLine, secondLine] = copy.welcomeTitle;
      element.replaceChildren(
        document.createTextNode(firstLine),
        document.createElement("br"),
        document.createTextNode(secondLine),
      );
    } else if (key === "menuTitle") {
      const brand = document.createElement("span");
      brand.textContent = "PAPATI";
      element.replaceChildren(...(language === "ar"
        ? [document.createTextNode(`${copy.menuTitle} `), brand]
        : [brand, document.createTextNode(` ${copy.menuTitle}`)]));
    } else {
      element.textContent = copy[key];
    }
  });
  document.querySelectorAll("[data-i18n-aria]").forEach((element) => {
    element.setAttribute("aria-label", copy[element.dataset.i18nAria]);
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    element.placeholder = copy[element.dataset.i18nPlaceholder];
  });

  const categoryLabels = {
    all: copy.categoryAll,
    hot: copy.categoryHot,
    cold: copy.categoryCold,
  };
  categoryButtons.forEach((button) => {
    button.textContent = categoryLabels[button.dataset.category];
  });
  languageToggles.forEach((toggle) => {
    toggle.textContent = language === "ar" ? "EN" : "ع";
    toggle.lang = language === "ar" ? "en" : "ar";
    toggle.setAttribute("aria-label", copy.switchLanguage);
    toggle.setAttribute("aria-pressed", String(language === "en"));
  });
  renderMenu();
}

categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    selectedCategory = button.dataset.category;
    animateMenuTransition = true;
    categoryButtons.forEach((categoryButton) => {
      const isSelected = categoryButton === button;
      categoryButton.classList.toggle("is-active", isSelected);
      categoryButton.setAttribute("aria-pressed", String(isSelected));
    });
    renderMenu();
  });
});

languageToggles.forEach((toggle) => {
  toggle.addEventListener("click", () => {
    setLanguage(currentLanguage === "ar" ? "en" : "ar");
  });
});

enterMenuButton.addEventListener("click", () => {
  welcomeScreen.classList.add("is-leaving");
  window.setTimeout(() => {
    welcomeScreen.hidden = true;
    siteContent.hidden = false;
    document.querySelector("#menu").scrollIntoView({ behavior: "smooth", block: "start" });
  }, 220);
});

searchInput.addEventListener("input", renderMenu);
setLanguage(currentLanguage);
